// JavaScript Document

//pickle jar
var firstName = " Marco";

//fire alert, add string, concatenate, dump in varibale
// //The alert() method displays an alert box
// alert("Hello"+firstName);

// alert(`Hello ${firstName}!!!`);

console.log(firstName);